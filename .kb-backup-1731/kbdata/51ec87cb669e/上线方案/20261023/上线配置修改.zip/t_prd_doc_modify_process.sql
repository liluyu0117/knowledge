/*
 Navicat Premium Data Transfer

 Source Server         : liangyi_idc
 Source Server Type    : MySQL
 Source Server Version : 80028
 Source Host           : 10.43.25.27:3306
 Source Schema         : chntitom_demand_lifecycle

 Target Server Type    : MySQL
 Target Server Version : 80028
 File Encoding         : 65001

 Date: 22/10/2026 11:30:19
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for t_prd_doc_modify_process
-- ----------------------------
CREATE TABLE `t_prd_doc_modify_process`  (
  `id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '主键（UUID）',
  `process_name` varchar(256) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '变更流程名称（需求限≤50字符）',
  `work_order_number` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '文档变更单号（平台统一规则生成）',
  `change_reason` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL COMMENT '变更原因（不限字符数）',
  `instance_id` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '变更流程实例ID(t_flow_instance.instance_id)',
  `association_confirmation_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '原流程业务行ID(t_prd_confirmation.id)',
  `association_instance_id` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '原流程实例ID(t_flow_instance.instance_id)',
  `association_child_ticket_no` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '关联子工单编号（客服工单号）',
  `association_parent_ticket_no` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '关联父工单编号（无父工单则空）',
  `flow_type` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT 'province_city_personal / center_plan',
  `system_name` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '系统名称',
  `business_line` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '业务线',
  `flow_status` varchar(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT 'deal' COMMENT 'deal进行中 / end已完成 / cancel已撤销',
  `estimated_workload` int NULL DEFAULT NULL COMMENT '预估工作量（人天，正整数）',
  `origin_prd_attachment_ids` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '变更前原PRD附件ID（逗号分隔）；覆盖PRD时写入，供详情页展示「变更前PRD」',
  `new_prd_attachment_ids` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '本次变更后新PRD附件ID（逗号分隔）；覆盖PRD时写入，供详情页展示「变更后PRD」',
  `create_by` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '创建人',
  `create_time` datetime NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_by` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '更新人',
  `update_time` datetime NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `uk_work_order_number`(`work_order_number`) USING BTREE,
  INDEX `idx_instance_id`(`instance_id`) USING BTREE,
  INDEX `idx_assoc_instance_status`(`association_instance_id`, `flow_status`) USING BTREE,
  INDEX `idx_assoc_confirmation_id`(`association_confirmation_id`) USING BTREE,
  INDEX `idx_assoc_child_ticket_no`(`association_child_ticket_no`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci COMMENT = 'PRD文档变更流程-变更工单表' ROW_FORMAT = Dynamic;

SET FOREIGN_KEY_CHECKS = 1;
